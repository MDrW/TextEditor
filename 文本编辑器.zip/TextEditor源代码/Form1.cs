﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace TextEditor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            undo.Push(richTextBox1);
        }

        //可操作的文件类型
        static private string filetype = "All type|*.*|Nomal text file|*.txt"
               + "|C# source file|*.cs|C/C++ source file|*.c;*.cpp"
               + "|Python source file|*.py|Java source file|*.java";
        const int stack_size = 2000;                    //撤销和重做存储操作的堆栈大小
        Undo_Redo undo = new Undo_Redo(stack_size);     //撤销存储操作使用的堆栈
        Undo_Redo redo = new Undo_Redo(stack_size);     //重做存储操作使用的堆栈
        bool f_undo = false;                            //撤销操作的标志

        //新建文件
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (save) saveFile();
            this.richTextBox1.Text = "";
            this.richTextBox1.Font = new Font("宋体", 10);
            this.richTextBox1.ForeColor = Color.Black;
            this.richTextBox1.BackColor = Color.White;
            this.fontDialog1.Font = new Font("宋体", 10);
            this.colorDialog1.Color = Color.Black;
            this.colorDialog2.Color = Color.White;
            this.Text = "new file-TextEditor";
            save = false;
            undo.Clear();redo.Clear();
            undo.Push(richTextBox1);
        }

        //打开文件
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (save) saveFile();
            openFileDialog1.Filter = filetype;
            openFileDialog1.ShowDialog();
            string filepath = openFileDialog1.FileName;
            string contents = File.FileOpen(filepath);
            if(contents != null)
            {
                this.Text = filepath + "-TextEditor";
                save = false;
                this.richTextBox1.Text = contents;
            }
            undo.Clear(); redo.Clear();
            undo.Push(richTextBox1);
        }

        //保存文件
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFile();
            undo.Clear(); redo.Clear();
        }
        //根据文件路径保存文件
        private void saveFile()
        {
            string filepath = this.Text.Substring(0,
                this.Text.Length - "-TextEditor".Length);
            if (MessageBox.Show("是否保存当前文件？",
                "温馨提示",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question)
                == DialogResult.Yes)
            {
                if (filepath.IndexOf('\\') < 0)
                    saveFileAs();
                else
                {
                    string contents = shownum ? ShowLineNum(true) : richTextBox1.Text;
                    File.FileWrite(filepath, contents);
                }
            }
        }

        //将文件另存为...
        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileAs();
            undo.Clear(); redo.Clear();
        }
        //根据文件路径将文件另存为
        private void saveFileAs()
        {
            saveFileDialog1.Filter = filetype;
            saveFileDialog1.ShowDialog();
            string filepath = saveFileDialog1.FileName;
            if (filepath != null && filepath != "" && filepath.IndexOf('\\') >= 0)
            {
                string contents = shownum ? ShowLineNum(true) : richTextBox1.Text;
                File.FileWrite(filepath, contents);
            }
            else
            {
                MessageBox.Show("文件路径无效！", "温馨提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //退出文本编辑器
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (save) saveFile();
            this.Dispose();
        }

        //设置字体
        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();
            Font font = fontDialog1.Font;
            if (this.richTextBox1.SelectedText != "")
                this.richTextBox1.SelectionFont = font;
            else
                this.richTextBox1.Font = font;
        }

        //设置字体颜色
        private void colorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            Color color = colorDialog1.Color;
            if (this.richTextBox1.SelectedText != "")
                this.richTextBox1.SelectionColor = color;
            else
                this.richTextBox1.ForeColor = color;
        }

        //设置背景颜色
        private void backgroundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog2.ShowDialog();
            Color color = colorDialog2.Color;
            if (this.richTextBox1.SelectedText == "")
            {
                this.richTextBox1.BackColor = color;
            }
            else
                this.richTextBox1.SelectionBackColor = color;
        }

        //选中所有文本
        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.richTextBox1.SelectAll();
        }

        //剪切文本
        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.richTextBox1.Cut();
        }

        //复制文本
        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.richTextBox1.Copy();
        }

        //粘贴文本
        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.richTextBox1.Paste();
        }

        //删除文本
        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int start = this.richTextBox1.SelectionStart;
            int length = this.richTextBox1.SelectionLength;
            string s = this.richTextBox1.Text;
            this.richTextBox1.Text = s.Remove(start, length);
        }

        //统计文本中的文字、数字、空格和其他字符的个数
        private void statusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string contents = this.richTextBox1.Text;
            int word = 0, num = 0, space = 0, others = 0;
            foreach(char c in contents)
            {
                if (c >= '0' && c <= '9') num++;            //统计数字的个数
                else if (c == ' ') space++;                 //统计空格的个数
                else if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
                    word++;
                else if (c >= 0x4e00 && c <= 0x9fa5)
                    word++;                                 //统计字母和中文字符的个数
            }
            int total_num = shownum ? (contents.Length - number * 5) : contents.Length;
            others = total_num - word - num - space;        //其他字符的个数
            MessageBox.Show("文字：   " + word + "\n" +
                "数字：   " + num + "\n" +
                "空格：   " + space + "\n" +
                "其他：   " + others + "\n" +
                "总计：   " + total_num,
                "统计结果",
                MessageBoxButtons.OK,
                MessageBoxIcon.None);                       //显示最终结果
        }

        //关于，显示About窗体
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About about = new About();
            about.ShowDialog();
        }

        //帮助，显示Help窗体
        private void helpToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Help help = new Help();
            help.Show();
        }

        Search search;
        //查找，显示Search窗体
        private void findToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (search == null || search.IsDisposed) search = new Search();
            search.Click_Find(this.richTextBox1);
            search.Owner = this;
            search.Show();
        }

        //替换，显示Search窗体
        private void replaceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (search == null || search.IsDisposed) search = new Search();
            search.Click_Replace(this.richTextBox1);
            search.Owner = this;
            search.Show();
        }

        //标记，显示Search窗体
        private void markToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (search == null || search.IsDisposed) search = new Search();
            search.Click_Mark(this.richTextBox1);
            search.Owner = this;
            search.Show();
        }

        //清除标记，显示Search窗体
        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (search == null || search.IsDisposed) search = new Search();
            search.Click_Mark(this.richTextBox1);
            search.Owner = this;
            search.Show();
        }

        //撤销上一步操作
        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            redo.Push(richTextBox1);                //将执行撤销之前的文本框添加到重做的堆栈中
            undo.Pop(richTextBox1);                 //撤销的动作出栈
            f_undo = true;                          //撤销的标志置为true
        }

        //恢复上一步操作
        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this.richTextBox1.Redo();
            redo.Pop(richTextBox1);                 //执行重做，保存的文本框出栈
        }

        //标记行号
        private bool shownum = false;
        private void lineNumberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            shownum = !shownum;
            ShowLineNum(false);
            if (shownum) this.richTextBox1.ReadOnly = true;     //显示行号时，设置文本框为只读，防止用户更改文本
            else this.richTextBox1.ReadOnly = false;
        }

        private int number;
        //为每行添加行号
        private string ShowLineNum(bool is_save)
        {
            string contents = this.richTextBox1.Text, s, str = "";
            int n; number = 1;
            n = contents.IndexOf('\n');
            if(!is_save) this.richTextBox1.Text = "";
            while (n >= 0)
            {
                s = contents.Substring(0, n + 1);
                s = (!shownum||is_save) ? s.Substring(5) : Int_to_Str(number) + s;
                number++;
                if(!is_save) this.richTextBox1.Text += s;
                str += s;
                contents = contents.Substring(n + 1);
                n = contents.IndexOf('\n');
            }
            s = ((!shownum)|| is_save) ? contents.Substring(5) : 
                Int_to_Str(number) + contents;
            if(!is_save) this.richTextBox1.Text += s;
            str += s;
            if (shownum && !is_save) setrichTextBox();
            return str;
        }

        //在文本框中文本的每行添加行号，并设置行号的格式
        private void setrichTextBox()
        {
            string contents = this.richTextBox1.Text;
            int n = contents.IndexOf('\n'), total = 0;
            while(n >= 0)
            {
                this.richTextBox1.Select(total, 5);
                this.richTextBox1.SelectionBackColor = Color.LightGray;
                this.richTextBox1.SelectionProtected = true;
                total += n + 1;
                contents = contents.Substring(n + 1);
                n = contents.IndexOf('\n');
            }
            this.richTextBox1.Select(total, 5);
            this.richTextBox1.SelectionBackColor = Color.LightGray;
            this.richTextBox1.SelectionProtected = true;
        }

        //设置行号显示的格式
        private string Int_to_Str(int num)
        {
            string ns;
            if (num < 10) ns = "   " + num;
            else if (num < 100) ns = "  " + num;
            else if (num < 1000) ns = " " + num;
            else ns = num.ToString();
            return ns + " ";
        }

        //显示状态栏
        private bool status = false;
        private void statusToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (status)
            {
                this.statusStrip1.Visible = false; status = false;
            }
            else
            {
                ShowStatus();
                this.statusStrip1.Visible = true;status = true;
            }
        }
        //设置状态栏中显示的内容
        private void ShowStatus()
        {
            string filepath = this.Text.Substring(0,
                this.Text.Length - "-TextEditor".Length);
            if (filepath.IndexOf('\\') > 0)
                filepath = filepath.Substring(filepath.LastIndexOf('\\') + 1);
            this.toolStripStatusLabel1.Text = "正在操作的文件：" + filepath + ", ";
            string s = shownum ? "只读" : "可读可写";
            this.toolStripStatusLabel1.Text += "当前文件状态：" + s + "; ";
            this.toolStripStatusLabel2.Text = "共" + num + "个字符";
        }

        //文本框中的内容改变时
        private bool save = false;          //文件保存的标志
        private int num = 0;    
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            save = true;
            num = this.richTextBox1.Text.Length;
            num = shownum ? (num - number * 5) : num;
            if (statusStrip1.Visible)
                ShowStatus();

            if (f_undo) f_undo = false;
            else if (!undo.Push(richTextBox1))
            {
                undo.Init();undo.Push(richTextBox1);
            }

            if (search != null && !search.IsDisposed && !search._replace)
                search.Find(search.str);
        }
    }
}
