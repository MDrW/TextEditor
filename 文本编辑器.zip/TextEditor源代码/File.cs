﻿using System;
using System.Windows.Forms;
using System.IO;

namespace TextEditor
{
    class File
    {
        //打开文件
        static public string FileOpen(string filepath)
        {
            if (filepath != null && filepath != "" && filepath.IndexOf('\\') >= 0)
            {
                try
                {
                    FileStream file = new FileStream(filepath,
                        FileMode.Open, FileAccess.Read);
                    StreamReader infile = new StreamReader(
                        file, System.Text.Encoding.Default);
                    string contents = infile.ReadToEnd();          //打开文件读出文件内容
                    infile.Close();
                    return contents;
                }
                catch
                {
                    MessageBox.Show("打开指定文件失败！", "温馨提示",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            return null;
        }

        //打开文件并写入
        static public void FileWrite(string filepath, string contents)
        {
            try
            {
                FileStream file = new FileStream(filepath,
                    FileMode.OpenOrCreate, FileAccess.Write);
                StreamWriter outfile = new StreamWriter(
                    file, System.Text.Encoding.Default);            //打开文件
                int n = contents.IndexOf('\n');
                while (n >= 0)
                {
                    outfile.WriteLine(contents.Substring(0, n));
                    contents = contents.Substring(n + 1);
                    n = contents.IndexOf('\n');
                }                                                   //写入内容
                outfile.WriteLine(contents);
                outfile.Close();
            }
            catch
            {
                MessageBox.Show("文件写入失败！", "温馨提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
