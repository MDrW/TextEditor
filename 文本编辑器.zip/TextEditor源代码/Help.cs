﻿using System;
using System.Windows.Forms;

namespace TextEditor
{
    public partial class Help : Form
    {
        //初始化Help窗体，向其中添加软件的一些使用说明
        public Help()
        {
            InitializeComponent();
            this.richTextBox1.Text = p1 +
                p21 + p22 + p23 + p24 + p25 + p26 +
                p31 + p32 + p33 + p34 + p35 + p36 + p37 + p38 +
                p41 + p42 + p43 + p44 + p45 +
                p51 + p52 + p53 + p54 +
                p61 + p62 + p63 + p64 + p2 + s;
        }

        /**
        * 如下的文本均为Help窗体中显示的帮助内容（程序的使用说明）
        */
        private string p1 = "TextEditor是一款简单的文本编辑器，可用于进行简单的文本处理，"
            + "其使用方法与其他的文本编辑器相类似，操作指南如下：\n\n";

        private string p21 = "File Menu中的各项说明：\n";
        private string p22 = "New  --- 新建一个文本文件。\n";
        private string p23= "Open --- 打开一个文本文件。\n";
        private string p24 = "Save --- 保存修改后的文本文件。\n";
        private string p25 = "Save as --- 将文本另存为。\n";
        private string p26 = "Exit --- 退出该应用程序。\n\n";

        private string p31 = "Edit Menu中的各项说明：\n";
        private string p32 = "Undo --- 撤销上一步操作。\n";
        private string p33 = "Redo --- 恢复上一步操作。\n";
        private string p34 = "Cut  --- 剪切选中的文本（快捷键Ctrl+X）。\n";
        private string p35 = "Copy --- 复制选中的文本（快捷键Ctrl+C）。\n";
        private string p36 = "Paste --- 向指定的位置粘贴文本（快捷键Ctrl+V）。\n";
        private string p37 = "Delete --- 删除选中的文本。\n";
        private string p38 = "Select All --- 选中所有的文本（快捷键Ctrl+A）。\n\n";

        private string p41 = "Search Menu中的各项说明：\n";
        private string p42 = "Find --- 在文本中查找指定的字符串。\n";
        private string p43 = "Replace --- 将文本中指定的字符串替换为输入的字符串。\n";
        private string p44 = "Mark --- 在文本中标记指定的字符串。\n";
        private string p45 = "Clear --- 清除文本中的标记。\n\n";
        
        private string p51 = "Setting Menu中的各项说明：\n";
        private string p52 = "Font --- 对选定的或所有的字符串设置字体。\n";
        private string p53 = "ForeColor --- 对选定的或所有的字符串设置字体颜色。\n";
        private string p54 = "Background --- 对选定的或所有的字符串设置背景颜色。\n\n";

        private string p61 = "View Menu中的各项说明：\n";
        private string p62 = "Statistics --- 对文本中的文字、数字、空格等的个数进行统计。\n";
        private string p63 = "Status Bar --- 显示状态栏。\n";
        private string p64 = "Line Number --- 显示文本各行的行号。\n\n";

        private string p2 = "对于工具栏中的各项，可参看显示的名称选择相应的操作。\n\n";

        private string s = "本应用的解释权最终归开发者所有。仅供他人学习和参考，若有他用，请联系" +
            "1150990891@qq.com。未经本人同意，擅自使用该产品谋取利益者，必将追究法律责任！\n";
        
        //关闭并释放窗体
        private void btnOK_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
