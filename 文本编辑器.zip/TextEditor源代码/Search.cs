﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

namespace TextEditor
{
    public partial class Search : Form
    {
        public Search()
        {
            InitializeComponent();
        }

        //执行操作的标志；0---查找，1---替换，2---标记
        static private int flag = 0;
        private RichTextBox rtb;
        private RichTextBoxFinds f = RichTextBoxFinds.None;
        private int num = 0;
        private List<int> lst = new List<int>();
        private int location = -1;

        private Button Flag_Button()
        {
            Button button = null;
            switch (flag)
            {
                case 0:button = button1; break;
                case 1:button = button2; break;
                case 2:button = button3; break;
                default:button = null; break;
            }
            return button;
        }

        private void SetButton(Button button)
        {
            button.BackColor = Color.White;
            button.Enabled = false;
        }

        private void ResetButton(Button button)
        {
            button.BackColor = Color.LightGray;
            button.Enabled = true;
        }

        private void ClickButton(Button button,int index)
        {
            Button b = Flag_Button();
            ResetButton(b);
            SetButton(button);
            flag = index;
        }

        private void SetVisible(bool tf1, bool tf2)
        {
            this.label1.Visible = true;
            this.label2.Visible = tf1;
            this.textBox1.Visible = true;
            this.textBox2.Visible = tf1;
            this.checkBox1.Visible = true;
            this.button4.Text = (flag == 2) ? "标记>>" : "<<查找";
            this.button5.Text = (flag == 2) ? "全部标记" : "下一个";
            this.button4.Visible = true;
            this.button5.Visible = true;
            this.button6.Visible = true;
            this.button7.Visible = tf2;
            this.button7.Text = (flag == 1) ? "替换>>" : "清除>>";
            this.button8.Visible = tf2;
            this.button8.Text = (flag == 1) ? "全部替换" : "全部清除";
        }

        public void Click_Find(RichTextBox rtb)
        {
            ClickButton(button1, 0);
            this.rtb = rtb;
            SetVisible(false, false);
            this.textBox1.Text = rtb.SelectedText;
        }

        //Find
        private void button1_Click(object sender, EventArgs e)
        {
            Click_Find(rtb);
        }

        public void Click_Replace(RichTextBox rtb)
        {
            ClickButton(button2, 1);
            this.rtb = rtb;
            this.textBox1.Text = rtb.SelectedText;
            SetVisible(true, true);
        }

        //Replace
        private void button2_Click(object sender, EventArgs e)
        {
            Click_Replace(rtb);
        }

        public void Click_Mark(RichTextBox rtb)
        {
            ClickButton(button3, 2);
            this.rtb = rtb;
            this.textBox1.Text = rtb.SelectedText;
            SetVisible(false, true);
        }

        //Mark
        private void button3_Click(object sender, EventArgs e)
        {
            Click_Mark(rtb);
        }

        //是否区分大小写
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked) f = RichTextBoxFinds.MatchCase;
            else f = RichTextBoxFinds.None;
            string s = this.textBox1.Text;
            Find(s);
            location = -1;
            num = lst.Count;
            if (show) label3.Text = "共找到：" + num + "个匹配项.";
            label4.Visible = false;
        }

        //查找（上一个）/标记（下一个）
        private void button4_Click(object sender, EventArgs e)
        {
            replace = true;
            if (flag != 2) Last();
            else Next();
            replace = false;
        }

        private void Last()
        {
            if (lst.Count != 0)
            {
                if (location == -1) location = 0;
                else if (location == 0) location = lst.Count - 1;
                else location--;
                Find_One();
            }
            else
            {
                MessageBox.Show("未找到匹配项", "温馨提示");
            }
        }

        //下一个/全部标记
        private void button5_Click(object sender, EventArgs e)
        {
            replace = true;
            if (flag != 2) Next();
            else MarkAll();
            replace = false;
        }

        private void Next()
        {
            if (lst.Count != 0)
            {
                if (location == -1) location = 0;
                else if (location == lst.Count - 1) location = 0;
                else location++;
                Find_One();
            }
            else
            {
                MessageBox.Show("未找到匹配项", "温馨提示");
            }
        }

        private void Find_One()
        {
            int length = this.textBox1.Text.Length;
            int i = lst[location];
            rtb.Select(i, length);
            if (flag == 2) rtb.SelectionBackColor = Color.LightGreen;
            rtb.Focus();
            label4.Text = "查找的第" + (location + 1) + "项";
            label4.Visible = true;
        }

        //标记找到的所有字符串
        private void MarkAll()
        {
            if(lst.Count != 0)
            {
                int length = this.textBox1.Text.Length;
                for(int i = 0;i < lst.Count; i++)
                {
                    int start = lst[i];
                    rtb.Select(start, length);
                    rtb.SelectionBackColor = Color.LightGreen;
                }
                label4.Visible = false;
            }
            else
            {
                MessageBox.Show("未找到匹配项", "温馨提示");
            }
        }

        //计数
        private bool show = false;
        private void button6_Click(object sender, EventArgs e)
        {
            show = !show;
            this.label3.Text = "共找到：" + lst.Count + "个匹配项.";
            this.label3.Visible = show;
        }

        //替换/清除
        private bool replace = false;
        private void button7_Click(object sender, EventArgs e)
        {
            replace = true;
            if (lst.Count > 0)
            {
                if (location == lst.Count - 1) location = 0;
                else location++;
                int length = this.textBox1.Text.Length;
                int i = lst[location];
                rtb.Select(i, length);
                if (flag == 1)
                {
                    rtb.SelectedText = this.textBox2.Text;
                    lst.Remove(i);location--;
                    label3.Visible = false;
                    int gap = textBox2.Text.Length - length;
                    for (int j = location + 1; j < lst.Count; j++)
                        lst[j] += gap;
                }
                else if (flag == 2)
                    rtb.SelectionBackColor = Color.White;
                rtb.Focus();
                label4.Visible = false;
            }
            else
            {
                MessageBox.Show("未找到匹配项", "温馨提示");
            }
            replace = false;
        }

        //全部替换/全部清除
        private void button8_Click(object sender, EventArgs e)
        {
            replace = true;
            if(lst.Count > 0)
            {
                int length = this.textBox1.Text.Length;
                int n = 0, gap = textBox2.Text.Length - length;
                for (int i = 0; i < lst.Count; i++)
                {
                    int start = (flag == 2) ? lst[i] : lst[i] + n * gap;
                    n++;
                    rtb.Select(start, length);
                    if(flag == 2) rtb.SelectionBackColor = Color.White;
                    else
                    {
                        rtb.SelectedText = textBox2.Text;
                        lst.Remove(lst[i]);i--;
                    }
                }
                if (flag == 1) label3.Visible = false;
                label4.Visible = false;
            }
            else
            {
                MessageBox.Show("未找到匹配项", "温馨提示");
            }
            replace = false;
        }
        
        public void Find(string s)
        {
            int start = 0, len = rtb.Text.Length - s.Length;
            lst = new List<int>();
            start = rtb.Find(s, start, f);
            while(start != -1 && start < len)
            {
                lst.Add(start);
                start = start + s.Length;
                start = rtb.Find(s, start, f);
            }
            if (start == len) lst.Add(start);
        }

        //获得文本框中的内容
        public string str
        {
            get
            {
                return this.textBox1.Text;
            }
        }
        //获得替换的标志
        public bool _replace
        {
            get
            {
                return this.replace;
            }
        }

        //输入文本框内容改变时的响应事件
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string s = this.textBox1.Text;
            Find(s);
            location = -1;
            num = lst.Count;
            if (show) label3.Text = "共找到：" + num + "个匹配项.";
            label4.Visible = false;
        }
    }
}
