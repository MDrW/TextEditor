﻿using System;
using System.Windows.Forms;

namespace TextEditor
{
    public partial class About : Form
    {
        public About()
        {
            InitializeComponent();
        }
        //响应用户点击确认按钮的事件，关闭并释放About窗体
        private void btnOK_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
