﻿using System;
using System.Windows.Forms;

namespace TextEditor
{
    /**
    * 撤销和重做操作需要的堆栈
    */
    class Undo_Redo
    {
        RichTextBox[] rtb;          //堆栈的存储空间
        int top;                    //栈顶指针
        int size;                   //栈的大小

        //堆栈的初始化
        public Undo_Redo(int size)
        {
            rtb = new RichTextBox[size];
            this.size = size;
            top = 0;
        }

        //文本框内容的复制
        private void rtbCopy(RichTextBox rtb1,RichTextBox rtb2)
        {
            rtb2.Text = rtb1.Text;
            /*if(rtb1.SelectedText != "")
            {
                rtb2.SelectionStart = rtb1.SelectionStart;
                rtb2.SelectionLength = rtb1.SelectionLength;
                rtb2.SelectionFont = rtb1.SelectionFont;
                rtb2.SelectionBackColor = rtb1.SelectionBackColor;
                rtb2.SelectionColor = rtb1.SelectionColor;
            }
            else
            {
                rtb2.Font = rtb1.Font;
                rtb2.ForeColor = rtb1.ForeColor;
                rtb2.BackColor = rtb1.BackColor;
            }*/
        }

        //元素入栈
        public bool Push(RichTextBox tb)
        {
            RichTextBox ntb = new RichTextBox();
            rtbCopy(tb, ntb);
            if (IsFull() || (top > 0 && tb.Text == rtb[top - 1].Text))
                return false;
            rtb[top] = ntb;
            top++;
            return true;
        }

        //元素出栈
        public bool Pop(RichTextBox tb)
        {
            RichTextBox ntb = new RichTextBox();
            if (IsEmpty()) return false;
            do
            {
                top--;
                ntb = rtb[top];
            } while (tb.Text == ntb.Text && top > 0);
            if (top <= 0) top = 1;
            rtbCopy(ntb, tb);
            return true;
        }

        //判断堆栈是否为空
        public bool IsEmpty()
        {
            if (top > 0) return false;
            return true;
        }

        //判断堆栈是否已满
        public bool IsFull()
        {
            if (top >= size) return true;
            return false;
        }

        //清空堆栈
        public void Clear()
        {
            rtb = new RichTextBox[size];
            top = 0;
        }

        //初始化堆栈
        public void Init()
        {
            top = 1;
        }
    }
}
